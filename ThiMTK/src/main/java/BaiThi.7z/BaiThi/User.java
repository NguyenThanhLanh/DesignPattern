/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BaiThi;

/**
 *
 * @author L_DELL
 */
public class User {
    String userId;
    String userName;
    String email;
    int yearOfBirth;

    public User(String userId, String userName, String email, int yearOfBirth) {
        this.userId = userId;
        this.userName = userName;
        this.email = email;
        this.yearOfBirth = yearOfBirth;
    }
    
}
